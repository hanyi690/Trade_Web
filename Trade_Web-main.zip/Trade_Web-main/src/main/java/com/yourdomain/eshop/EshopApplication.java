package com.yourdomain.eshop;

import java.math.BigDecimal;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

import com.yourdomain.eshop.entity.Product;
import com.yourdomain.eshop.entity.Category;
import com.yourdomain.eshop.repository.ProductRepository;
import com.yourdomain.eshop.repository.CategoryRepository;

@SpringBootApplication
public class EshopApplication extends SpringBootServletInitializer implements CommandLineRunner {
	private final ProductRepository productRepository;
	private final CategoryRepository categoryRepository;

	// 构造注入仓库
	public EshopApplication(ProductRepository productRepository, CategoryRepository categoryRepository) {
		this.productRepository = productRepository;
		this.categoryRepository = categoryRepository;
	}

	public static void main(String[] args) {

		SpringApplication.run(EshopApplication.class, args);
	
	}

	
	@Override
	public void run(String... args) {
	    try {
	        // 仅在产品表为空时插入示例数据，避免重复插入
	        if (productRepository.count() == 0) {
	            // 创建默认分类并保存
	            Category defaultCategory = new Category();
	            defaultCategory.setName("默认分类");
	            defaultCategory = categoryRepository.save(defaultCategory);

	            // 创建产品（使用现有 Product 字段）
	            Product product = new Product();
	            product.setName("示例商品");
	            product.setDescription("这是一个示例商品");
	            product.setPrice(BigDecimal.valueOf(19.99));// 使用 Double 类型价格
	            product.setImageFilename("default.png"); // 示例图片文件名（可选）
	            product.setCategory(defaultCategory); // 设置分类关联

	            productRepository.save(product);
	            System.out.println("示例数据插入成功");
	        }
	    } catch (Exception e) {
	        System.err.println("数据初始化失败，但应用可以继续运行: " + e.getMessage());
	        // 不抛出异常，让应用继续启动
	    }
	}
}